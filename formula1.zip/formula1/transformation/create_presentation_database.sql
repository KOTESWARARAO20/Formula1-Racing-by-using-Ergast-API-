-- Databricks notebook source
create database if not exists f1_presentation 
location "/mnt//formula1dl62/presentation"

-- COMMAND ----------

