# Databricks notebook source
# MAGIC %md
# MAGIC ####read the data as required

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

drivers_df=spark.read.parquet(f"{processed_folder_path}/drivers_parquet").withColumnRenamed("number","drive_number")\
.withColumnRenamed('name',"driver_name")\
.withColumnRenamed("nationality","driver_nationality")

# COMMAND ----------

display(drivers_df)

# COMMAND ----------

constructors_df=spark.read.parquet(f"{processed_folder_path}/constructor_parquet").withColumnRenamed("name","team")


# COMMAND ----------

circuits_df=spark.read.parquet(f"{processed_folder_path}/circuits_parquet").withColumnRenamed("location","circuit_location")

# COMMAND ----------

races_df=spark.read.parquet(f"{processed_folder_path}/races_parquet")\
.withColumnRenamed("name","race_name")\
.withColumnRenamed("race_timestamp","race_date")

# COMMAND ----------

results_df=spark.read.parquet(f"{processed_folder_path}/results_parquet")\
.withColumnRenamed("time","race_time")

# COMMAND ----------

# MAGIC %md
# MAGIC #### join the circuits to races

# COMMAND ----------

races_circuits_df=races_df.join(circuits_df,races_df.circuit_id==circuits_df.circuit_id,"inner").select(races_df.race_year,races_df.race_id,races_df.race_name,races_df.race_date,circuits_df.circuit_location)

# COMMAND ----------

display(races_circuits_df)
races_circuits_df.count()


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Join results to all other dataframes

# COMMAND ----------

race_result_df=results_df.join(races_circuits_df,results_df.race_id==races_circuits_df.race_id)\
.join(drivers_df,results_df.driver_id==drivers_df.driver_id)\
.join(constructors_df,results_df.constructor_id==constructors_df.constructor_id)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp

# COMMAND ----------

final_df=race_result_df.select("race_year","race_name","race_date","circuit_location","driver_name","driver_nationality","team","grid","fastest_lap","race_time","points","position").withColumn("created_date",current_timestamp())


# COMMAND ----------

display(final_df)

# COMMAND ----------

#df0=final_df.write.mode("overwrite").parquet(f"{presentation_folder_path}/race_orgianl_record_results_parquet")

# COMMAND ----------

final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_presentation.race_result_standing_sql")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.race_sql_results;

# COMMAND ----------

display(spark.read.parquet(f"{presentation_folder_path}/race_orgianl_record_results_parquet"))

# COMMAND ----------

d1=final_df.filter("race_year in(2019,2020)")


# COMMAND ----------


d1.write.mode("overwrite").parquet(f"{presentation_folder_path}/race_dummy1_results_parquet")

# COMMAND ----------

display(spark.read.parquet(f"{presentation_folder_path}/race_dummy1_results_parquet"))

# COMMAND ----------

dummy=final_df.where("race_year==2020")
display(dummy)

# COMMAND ----------

dummy.write.mode("overwrite").parquet(f"{presentation_folder_path}/race_dummy_results_parquet")

# COMMAND ----------

display(spark.read.parquet(f"{presentation_folder_path}/race_dummy_results_parquet"))

# COMMAND ----------

display(final_df.where("race_year==2020 and race_name =='Abu Dhabi Grand Prix' "))


# COMMAND ----------



# COMMAND ----------

final_df1=final_df.where("race_year==2020 and race_name =='Abu Dhabi Grand Prix' ").orderBy(final_df.points.desc())

# COMMAND ----------

display(final_df1)

# COMMAND ----------

#https://www.bbc.com/sport/formula1/2020/abu-dhabi-grand-prix/results

# COMMAND ----------

final_df1.write.mode("overwrite").parquet(f"{presentation_folder_path}/race_final_results_parquet")

# COMMAND ----------

display(spark.read.parquet(f"{presentation_folder_path}/race_final_results_parquet"))

# COMMAND ----------

