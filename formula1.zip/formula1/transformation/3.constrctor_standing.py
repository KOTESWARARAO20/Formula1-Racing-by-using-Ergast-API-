# Databricks notebook source
# MAGIC %md
# MAGIC ### Produce Constrctor Standardings

# COMMAND ----------

#https://www.bbc.com/sport/formula1/constructors-world-championship/standings

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

constructor_results_df=spark.read.parquet(f"{presentation_folder_path}/race_orgianl_record_results_parquet")

# COMMAND ----------

constructor_standings_df=constructor_results_df.filter("race_year=2020")
display(constructor_standings_df)

# COMMAND ----------

from pyspark.sql.functions import sum,count,when,col


# COMMAND ----------

constructor_standings_grouped_df=constructor_results_df\
.groupBy("race_year","team")\
.agg(sum("points").alias("total_points"),
     count(when(col("position")==1,True)).alias("wins"))

# COMMAND ----------

display(constructor_standings_grouped_df)

# COMMAND ----------

constructor_standings_df=constructor_standings_grouped_df.filter("race_year=2020")
display(constructor_standings_df)

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import desc,rank,asc

# COMMAND ----------

constructor_rank_spec=Window.partitionBy("race_year").orderBy(desc("total_points"),desc("wins"))
final_df=constructor_standings_df.withColumn("rank",rank().over(constructor_rank_spec))

# COMMAND ----------

display(final_df)

# COMMAND ----------

#final_df.write.mode("overwrite").parquet(f"{presentation_folder_path}/constructor_standings_parquet")

# COMMAND ----------

final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_presentation.constructor_standings_sql");

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_presentation.constructor_standings_sql;

# COMMAND ----------

display(spark.read.parquet(f"{presentation_folder_path}/constructor_standings_parquet"))

# COMMAND ----------

