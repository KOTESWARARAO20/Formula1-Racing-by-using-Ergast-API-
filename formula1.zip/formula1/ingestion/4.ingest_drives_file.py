# Databricks notebook source
# MAGIC %md
# MAGIC #### Ingest drives.json file

# COMMAND ----------

# MAGIC %md
# MAGIC ####Read the drivers json file

# COMMAND ----------

from pyspark.sql.types import IntegerType,StringType,DateType,StructField,StructType


# COMMAND ----------

name_schme=StructType(fields=[StructField("forename",StringType(),True),
                             StructField("surname",StringType(),True)
                             
                     
                            ])

# COMMAND ----------

drives_schema = StructType(fields=[StructField("driverId",IntegerType(),False),
                                   StructField("driverRef",StringType(),True),
                                   StructField("number",IntegerType(),True),
                                   StructField("code",StringType(),True),
                                   StructField("name",name_schme),
                                   StructField("dob",DateType(),True),
                                   StructField("nationality",StringType(),True),
                                   StructField("url",StringType(),True)]) 
                                   
                                 
                                 
                                 

# COMMAND ----------

display(drives_schema)

# COMMAND ----------

drives_df=spark.read\
.schema(drives_schema)\
.json("/mnt/formula1dl62/raw/drivers.json")

# COMMAND ----------

display(drives_df)

# COMMAND ----------

from pyspark.sql.functions import col,concat,current_timestamp,lit


# COMMAND ----------

drives_withcol_df=drives_df.withColumnRenamed("driverId","driver_id")\
.withColumnRenamed("driverRef","driver_ref")\
.withColumn("ingestion_date",current_timestamp())\
.withColumn("name",concat(col("name.forename"),lit(" "),col("name.surname")))

# COMMAND ----------

display(drives_withcol_df)


# COMMAND ----------

drives_final_df=drives_withcol_df.drop("url")

# COMMAND ----------

display(drives_final_df)

# COMMAND ----------

#df=drives_final_df.write.mode("overwrite").parquet("/mnt/formula1dl62/processed/drivers_parquet")

# COMMAND ----------

drives_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.drivers");

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.drivers;

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dl62/processed/drivers_parquet"))

# COMMAND ----------

