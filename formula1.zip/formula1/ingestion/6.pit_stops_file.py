# Databricks notebook source
# MAGIC %md
# MAGIC ###Read the pitstops json file

# COMMAND ----------

from pyspark.sql.types import  StructField,IntegerType,StringType,DoubleType,StructType,DateType,FloatType

# COMMAND ----------

pit_stop_schema=StructType(fields=[StructField("raceId",IntegerType(),False),
                                 StructField("driverId",IntegerType(),True),
                                 StructField("stop",StringType(),True),
                                 StructField("lap",IntegerType(),True),
                                 StructField("time",StringType(),True),
                                 StructField("duration",StringType(),True),
                                 StructField("milliseconds",StringType(),True)])

# COMMAND ----------

pit_stop_df=spark.read.schema(pit_stop_schema).option("multiLine",True).json("/mnt/formula1dl62/raw/pit_stops.json")

# COMMAND ----------

display(pit_stop_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###step2: Rename the cloumns and add new cloumns

# COMMAND ----------

 from pyspark.sql.functions import current_timestamp

# COMMAND ----------

pit_final_df=pit_stop_df.withColumnRenamed("raceId","race_id")\
.withColumnRenamed("driverId","driver_id")\
.withColumn("ingestion_date",current_timestamp())


# COMMAND ----------

display(pit_final_df)

# COMMAND ----------

#%md
####parquet writer



# COMMAND ----------

#pit_stop_parquet=pit_final_df.write.mode("OverWrite").parquet("/mnt/formula1dl62/processed/pit_stop_parquet")

# COMMAND ----------

pit_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.pitstop");

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.pitstop;

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dl62/processed/pit_stop_parquet"))

# COMMAND ----------

