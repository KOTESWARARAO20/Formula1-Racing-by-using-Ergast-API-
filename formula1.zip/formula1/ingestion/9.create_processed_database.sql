-- Databricks notebook source
create database if not exists f1_processed
location "/mnt/formula1dl62/processed"

-- COMMAND ----------

desc database f1_processed;

-- COMMAND ----------

circuits_final_df.write.mode("overwrite").format("parquet").saveAsTable("
f1_processed.circuits");

-- COMMAND ----------

