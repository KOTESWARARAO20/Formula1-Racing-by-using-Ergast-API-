# Databricks notebook source
# MAGIC %md
# MAGIC #### Ingest the Race.csv file

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step 1: Read the data from race.csv using dataframe reader

# COMMAND ----------

display(dbutils.fs.mounts())


# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dl62/raw

# COMMAND ----------

races_df=spark.read.option('header',True).csv("dbfs:/mnt/formula1dl62/raw/races.csv")

# COMMAND ----------

display(races_df)

# COMMAND ----------

races_df.printSchema()

# COMMAND ----------

from pyspark.sql.types import StructField,IntegerType,StringType,DoubleType,StructType,DateType

# COMMAND ----------

#strcut type represnt rows and strcut fileds represnets ass cloumns
races_schema=StructType(fields=[StructField("raceId",IntegerType(),False),
                                 StructField("year",IntegerType(),True),
                                 StructField("round",IntegerType(),True),
                                 StructField("circuitId",IntegerType(),True),
                                 StructField("name",StringType(),True),
                                 StructField("date", DateType(), True),
                                 StructField("time",StringType(),True),
                                 
                                 StructField("url",StringType(),True)
                                 
                                 
                                 
                                 
                                 
    
])

# COMMAND ----------

races_df=spark.read\
.option('header',True)\
.schema(races_schema)\
.csv("/mnt/formula1dl62/raw/races.csv")

# COMMAND ----------

display(races_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Add Ingestion date and Race time stamp cloumns

# COMMAND ----------

#from pyspark.sql.functions import col
from pyspark.sql.functions import current_timestamp,lit,to_timestamp,concat,col

# COMMAND ----------

races_with_timestamp_df=races_df\
.withColumn("ingestion_date",current_timestamp())\
.withColumn('race_timestamp',to_timestamp(concat(col('date'),lit(' '),col('time')),'yyyy-MM-dd HH:mm:ss'))

# COMMAND ----------

display(races_with_timestamp_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Selecting Required columns

# COMMAND ----------

races_renamed_df=races_with_timestamp_df.withColumnRenamed("raceId","race_id")\
.withColumnRenamed("year","race_year")\
.withColumnRenamed("circuitId","circuit_id")\
.withColumnRenamed("race_timestamp","race_timestamp")\
.withColumnRenamed("ingestion_date","ingestion_date")

# COMMAND ----------

display(races_renamed_df)

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

races_selected_df=races_renamed_df.select('race_id','race_year','name','circuit_id','round','ingestion_date','race_timestamp')

# COMMAND ----------

display(races_selected_df)

# COMMAND ----------

# MAGIC %md 
# MAGIC #### write the data as parquet to processed content

# COMMAND ----------

#races_parquet_df=races_selected_df.write.mode("overwrite").partitionBy('race_year').parquet('/mnt/formula1dl62/processed/races_parquet')

# COMMAND ----------

races_selected_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.races");

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.races;

# COMMAND ----------

#pyspark tho rasainivaise
display(spark.read.parquet("/mnt/formula1dl62/processed/races_parquet"))

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dl62/processed/races_parquet

# COMMAND ----------

