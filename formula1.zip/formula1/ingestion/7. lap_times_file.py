# Databricks notebook source
# MAGIC %md
# MAGIC ###Read the lap_times csv file

# COMMAND ----------

from pyspark.sql.types import  StructField,IntegerType,StringType,DoubleType,StructType,DateType,FloatType

# COMMAND ----------

lap_times_schema=StructType(fields=[StructField("raceId",IntegerType(),False),
                                 StructField("driverId",IntegerType(),True),
                                 StructField("lap",IntegerType(),True),
                                 StructField("position",IntegerType(),True),
                                 StructField("time",StringType(),True),
                                 
                                 StructField("milliseconds",StringType(),True)])

# COMMAND ----------

lap_times_df=spark.read.schema(lap_times_schema).csv("/mnt/formula1dl62/raw/lap_times/lap_times_split*.csv")

# COMMAND ----------

display(lap_times_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###step2: Rename the cloumns and add new cloumns

# COMMAND ----------

 from pyspark.sql.functions import current_timestamp

# COMMAND ----------

lap_times_final_df=lap_times_df.withColumnRenamed("raceId","race_id")\
.withColumnRenamed("driverId","driver_id")\
.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

#display(lap_times_final_df.count())
display(lap_times_final_df)

# COMMAND ----------

#lap_time_parquet=lap_times_final_df.write.mode("overwrite").parquet("/mnt/formula1dl62/processed/lap_times_parquet")

# COMMAND ----------

lap_times_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.lap_times");


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.lap_times;

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dl62/processed/lap_times_parquet"))