# Databricks notebook source
dbutils.notebook.help()

# COMMAND ----------

#0 means there is time out so its default value
v_result = dbutils.notebook.run("qualifying_file",0,{"p_data_source":"Ergast API"})

# COMMAND ----------

v_result

# COMMAND ----------

#v=result=dbutils.notebook.run("1.ingest_circuit_id",0,{"p_data_source":"Ergast API"})
#need to write all the notbooks without any dependcy of the other notebooks and based previous notebook sequence will take decision


# COMMAND ----------

