# Databricks notebook source
# MAGIC %md
# MAGIC ###Read the qualifying csv  file

# COMMAND ----------

from pyspark.sql.types import  StructField,IntegerType,StringType,DoubleType,StructType,DateType,FloatType

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC ### passing parameters(widegets)

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

dbutils.widgets.text("p_data_source","")
var_data_source=dbutils.widgets.get("p_data_source")

# COMMAND ----------

var_data_source


# COMMAND ----------

qualifying_schema=StructType(fields=[StructField("qualifyId",IntegerType(),False),
                                 StructField("raceId",IntegerType(),True),
                                 StructField("driverId",IntegerType(),True),
                                 StructField("constructorId",IntegerType(),True),
                                 StructField("number",IntegerType(),True),
                                 StructField("position",IntegerType(),True),
                                 StructField("q1",StringType(),True),
                                 StructField("q2",StringType(),True),
                                 StructField("q3",StringType(),True)])

# COMMAND ----------

qualifying_df=spark.read.schema(qualifying_schema).option("multiLine",True).json(f"{raw_folder_path}/qualifying/qualifying_split_*.json")

# COMMAND ----------

display(qualifying_df)

# COMMAND ----------

qualifying_add_df=add_ingestion_date(qualifying_df)

# COMMAND ----------

display(qualifying_add_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###step2: Rename the cloumns and add new cloumns

# COMMAND ----------

 from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

qualifying_final_df=qualifying_add_df.withColumnRenamed("qualifyId","qualify_id")\
.withColumnRenamed("raceId","race_id")\
.withColumnRenamed('driverId','driver_id')\
.withColumnRenamed("constructorId","constructor_id")\
.withColumn("data_source",lit(var_data_source))


# COMMAND ----------

display(qualifying_final_df)

# COMMAND ----------

#%md
####parquet writer



# COMMAND ----------

#qualifying_parquet=qualifying_final_df.write.mode("OverWrite").parquet(f"{processed_folder_path}/qualifying_parquet")

# COMMAND ----------

qualifying_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.qualifying");

# COMMAND ----------

# MAGIC %sql
# MAGIC select *from f1_processed.qualifying;

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dl62/processed/qualifying_parquet"))


# COMMAND ----------

dbutils.notebook.exit("Sucess")

# COMMAND ----------

