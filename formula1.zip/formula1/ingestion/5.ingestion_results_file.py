# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest Results json file

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Read the data from result.json from reader

# COMMAND ----------

from pyspark.sql.types import  StructField,IntegerType,StringType,DoubleType,StructType,DateType,FloatType

# COMMAND ----------

result_schema=StructType(fields=[StructField("resultId",IntegerType(),False),
                                 StructField("raceId",IntegerType(),True),
                                 StructField("driverId",IntegerType(),True),
                                 StructField("constructorId",IntegerType(),True),
                                 StructField("number",IntegerType(),True),
                                 StructField("grid",IntegerType(),True),
                                 StructField("position",IntegerType(),True),
                                 StructField("positionText",StringType(),True),
                                 StructField("positionOrder",IntegerType(),True),
                                 StructField("points",FloatType(),True),
                                 StructField("laps",IntegerType(),True),
                                 StructField("time",StringType(),True),
                                 StructField("milliseconds",IntegerType(),True),
                                 StructField("fastestLap",IntegerType(),True),
                                 StructField("rank",IntegerType(),True),
                                 StructField("fastestLapTime",StringType(),True),
                                 StructField("fastestLapSpeed",FloatType(),True),
                                 StructField("statusId",IntegerType(),True),])
                                 
                                 
                                 

# COMMAND ----------

results_df=spark.read.schema(result_schema).json("/mnt/formula1dl62/raw/results.json")

# COMMAND ----------

display(results_df)

# COMMAND ----------

 from pyspark.sql.functions import current_timestamp

# COMMAND ----------

results_renamed_df=results_df.withColumnRenamed("raceId","race_id")\
.withColumnRenamed("resultId","result_id")\
.withColumnRenamed("driverId","driver_id")\
.withColumnRenamed("constructorId","constructor_id")\
.withColumnRenamed("positionText","position_text")\
.withColumnRenamed("positionOrder","position_order")\
.withColumnRenamed("positionOrder","position_order")\
.withColumnRenamed("fastestLap","fastest_lap")\
.withColumnRenamed("fastestLapTime","fastest_lap_time")\
.withColumnRenamed("fastestLapSpeed","fastest_lap_speed")

# COMMAND ----------

results_added_df=results_renamed_df.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

display(results_added_df)

# COMMAND ----------

results_final=results_added_df.drop("statusId")

# COMMAND ----------

display(results_final)

# COMMAND ----------

#write data to parquet and partition by race id

# COMMAND ----------

#result_parrquet=results_final.write.mode("overwrite").partitionBy("race_id").parquet("/mnt/formula1dl62/processed/results_parquet")

# COMMAND ----------

results_final.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.results");

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.results;

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dl62/processed/results_parquet"))


# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dl62/processed/results_parquet

# COMMAND ----------

