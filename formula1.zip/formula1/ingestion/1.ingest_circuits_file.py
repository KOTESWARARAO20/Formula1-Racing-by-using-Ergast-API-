# Databricks notebook source
# MAGIC %md
# MAGIC ##Ingest circuits.csv file

# COMMAND ----------

# MAGIC %md
# MAGIC ###Step1: Read the CSV file using the spark dataframe reader

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

#circuits_df=spark.read.option("header",True).csv('dbfs:/mnt/formula1dl62/raw/circuits.csv')

# COMMAND ----------

#dbutils.fs.mounts()

# COMMAND ----------

#display(dbutils.fs.mounts())

# COMMAND ----------

#%fs
#ls /mnt/formula1dl62/raw


# COMMAND ----------

#type(circuits_df)
#display(circuits_df)

# COMMAND ----------

#circuits_df.printSchema()

# COMMAND ----------

#display(circuits_df)

# COMMAND ----------

#display(circuits_df.describe())

# COMMAND ----------

from pyspark.sql.types import StructField,IntegerType,StringType,DoubleType,StructType

# COMMAND ----------

#strcut type represnt rows and strcut fileds represnets ass cloumns
circuts_schema=StructType(fields=[StructField("circuitId",IntegerType(),False),
                                 StructField("circuitRef",StringType(),True),
                                 StructField("name",StringType(),True),
                                 StructField("location",StringType(),True),
                                 StructField("country",StringType(),True),
                                 StructField("lat",DoubleType(),True),
                                 StructField("lng",DoubleType(),True),
                                 StructField("alt",IntegerType(),True),
                                 StructField("url",StringType(),True),
                                 
                                 
                                 
                                 
                                 
    
])

# COMMAND ----------

#raw_floder_path

# COMMAND ----------

circuits_df=spark.read\
.option("header",True)\
.schema(circuts_schema)\
.csv("/mnt/formula1dl62/raw/circuits.csv")

# COMMAND ----------

circuits_df.display()


# COMMAND ----------

circuits_df.printSchema()

# COMMAND ----------

# MAGIC %md
# MAGIC #Select only required Columns

# COMMAND ----------

circuits_seleceted_df=circuits_df.select('circuitId', 'circuitRef','name', 'location','country','lat', 'alt','lng')

# COMMAND ----------

display(circuits_seleceted_df)

# COMMAND ----------

#another way of selecting cloumns
circuits_seleceted_df=circuits_df.select(circuits_df.circuitId, circuits_df.circuitRef,circuits_df.name, circuits_df.location,circuits_df.country,circuits_df.lat, circuits_df.alt,circuits_df.lng)


# COMMAND ----------

#print(circuits_seleceted_df)

# COMMAND ----------

display(circuits_seleceted_df)


# COMMAND ----------

#3rd way of selecting the cloumns-dfname and [" surroend by ""]
circuits_seleceted_df=circuits_df.select(circuits_df['circuitId'], circuits_df['circuitRef'],circuits_df['name'], circuits_df['location'],circuits_df['country'],circuits_df['lat'], circuits_df['alt'],circuits_df['lng'])


# COMMAND ----------

display(circuits_seleceted_df)

# COMMAND ----------

#4th way by using function call
from pyspark.sql.functions import col
circuits_seleceted_df=circuits_df.select(col('circuitId'), col('circuitRef'),col('name'), col('location'),col('country'),col('lat'), col('alt'),col('lng'))


# COMMAND ----------

display(circuits_seleceted_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ###Step3: Rename the cloumns required

# COMMAND ----------

circuits_renamed_df=circuits_seleceted_df.withColumnRenamed("circuitId","circuit_id")\
.withColumnRenamed("circuitRef","circuit_ref")\
.withColumnRenamed("lat","latitude")\
.withColumnRenamed("lng","longitude")\
.withColumnRenamed("alt","altitude")

# COMMAND ----------

display(circuits_renamed_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Step 4:Add new cloumn ingest data cloumn 

# COMMAND ----------


from pyspark.sql.functions import current_timestamp,lit

# COMMAND ----------

circuits_final_df=circuits_renamed_df.withColumn("ingestion_date",current_timestamp())

# COMMAND ----------

display(circuits_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Step 5: Write data as parquet

# COMMAND ----------

#circuits_final_df.write.parquet('/mnt/formula1dl62/processed/circuits_parquet')

#circuits_final_df.write.mode("overwrite").parquet('/mnt/formula1dl62/processed/circuits_parquet')

# COMMAND ----------

circuits_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.circuits");

# COMMAND ----------

# MAGIC %sql
# MAGIC select *from f1_processed.circuits;

# COMMAND ----------

# MAGIC %fs
# MAGIC ls /mnt/formula1dl62/processed/circuits_parquet

# COMMAND ----------

df=spark.read.parquet("/mnt/formula1dl62/processed/circuits_parquet")

# COMMAND ----------

display(df)

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dl62/processed/circuits_parquet"))

# COMMAND ----------

