# Databricks notebook source
# MAGIC %md
# MAGIC ####Ingest the Constrctors.json file

# COMMAND ----------

# MAGIC %md
# MAGIC ##### Step 1: Read the JSON file using the spark dataframe reader

# COMMAND ----------

con_schema="constructorId INT,constructorRef STRING,name STRING,nationality STRING,url STRING"

# COMMAND ----------

constructor_df=spark.read.schema(con_schema)\
.json('dbfs:/mnt/formula1dl62/raw/constructors.json')

# COMMAND ----------

display(constructor_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Transform and write the data

# COMMAND ----------

# MAGIC %md
# MAGIC ####drop unwanted cloumns from the dataframe

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

#constructor_dropped_df=constructor_df.drop('url')

#multiple cloumns need to drop we need use this way
#constructor_dropped_df=constructor_df.drop(constructor_df['url'])

constructor_dropped_df=constructor_df.drop(col('url'))

# COMMAND ----------

# MAGIC %md
# MAGIC ####rename cloumns and add ingestion date

# COMMAND ----------

from pyspark.sql.functions import current_timestamp 

# COMMAND ----------

constructor_final_df=constructor_dropped_df.withColumnRenamed("constructorId","constructor_id")\
                                           .withColumnRenamed("constructorRef","constructor_ref")\
                                           .withColumn("ingestion-date",current_timestamp ())
    


# COMMAND ----------

display(constructor_final_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Step3: write data and transfer data to parquet

# COMMAND ----------

#constructor_parquet_df=constructor_final_df.write.mode("overwrite").parquet("/mnt/formula1dl62/processed/constructor_parquet")


# COMMAND ----------

constructor_final_df.write.mode("overwrite").format("parquet").saveAsTable("f1_processed.constructor");

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f1_processed.constructor;

# COMMAND ----------

display(spark.read.parquet("/mnt/formula1dl62/processed/constructor_parquet"))

# COMMAND ----------

