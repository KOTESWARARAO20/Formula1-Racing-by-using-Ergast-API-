# Databricks notebook source
# MAGIC %md
# MAGIC #Access dataframes using SQL
# MAGIC ##Objectives:
# MAGIC ####1.Create temp views on dataframes
# MAGIC ####2. Access the view from SQL cell
# MAGIC ####3. Access the view from Python cell

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_orgianl_record_results_parquet")

# COMMAND ----------

race_results_df.createTempView("v_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(1) from v_race_results where race_year='2020'

# COMMAND ----------

p_race_year=2019

# COMMAND ----------

# MAGIC %md
# MAGIC ######spark.sql is give the abilty to give the data into dataframe and make opeartions

# COMMAND ----------

races_results_df=spark.sql("select * from v_race_results where race_year=2020")

# COMMAND ----------

races_results_2019_df1=spark.sql(f"select * from v_race_results where race_year={p_race_year}")
display(races_results_2019_df1)

# COMMAND ----------

display(races_results_2019_df1)

# COMMAND ----------

'''these temp views are tempviews if deattached the cluster it will through errors and also we will not use outside of notebook also and these view scope upto this spark sesion inorder overcome this or else if run all the notebooks also it throws an error like temp view dfxyz is already exists show we need use createOrReplaceview keyword we need to use
'''


# COMMAND ----------

race_results_df2=race_results_df.createOrReplaceTempView("v_race_results")

# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from v_race_results where race_year='2017'

# COMMAND ----------

# MAGIC %md
# MAGIC ####Global Temporary views
# MAGIC ######1.Create Global temp views on dataframes
# MAGIC ######2.Acess the view from SQL Cell
# MAGIC ######3.Acess the view from another_notebook

# COMMAND ----------

race_results_df.createOrReplaceGlobalTempView("gv_race_results")

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables in global_temp;

# COMMAND ----------

#global_temp is global database object which is created by databricks
%sql
select * from gv_race_results;

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.gv_race_results;

# COMMAND ----------

spark.sql("select * from global_temp.gv_race_results").show()