-- Databricks notebook source
-- MAGIC %md
-- MAGIC #### Lesson Objectives
-- MAGIC ##### 1.Spark SQL Documentation
-- MAGIC ##### 2. Create dataframe Demo
-- MAGIC ##### 3. Database tab in the UI
-- MAGIC ##### 4.SHOW command
-- MAGIC ##### 5.DESCRIBE command
-- MAGIC ##### 6.Find the current DB

-- COMMAND ----------

CreateOrReplace DATABASE demo;

-- COMMAND ----------

CREATE DATABASE demo;

-- COMMAND ----------

CREATE DATABASE if not exists demo;

-- COMMAND ----------

show databases;

-- COMMAND ----------

DESCRIBE database demo;


-- COMMAND ----------

#extended used for checking properties
DESCRIBE database EXTENDED demo;

-- COMMAND ----------

select current_database();

-- COMMAND ----------

show tables;

-- COMMAND ----------

show tables in demo;


-- COMMAND ----------

use demo;

-- COMMAND ----------

select current_database()

-- COMMAND ----------

show tables;

-- COMMAND ----------

show tables in default

-- COMMAND ----------

-- MAGIC %run "../includes/configurations"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df= spark.read.parquet(f"{presentation_folder_path}/race_orgianl_record_results_parquet")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("demo.race_results.python")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").mode("overwrite").saveAsTable("demo.race_results_python")

-- COMMAND ----------

show tables;


-- COMMAND ----------

desc EXTENDED race_results_python;

-- COMMAND ----------



-- COMMAND ----------

SELECT *from demo.race_results_python where race_year=2020;

-- COMMAND ----------

createOrReplace table demo.race_results_sql
as
SELECT *from demo.race_results_python where race_year=2020;

-- COMMAND ----------

select current_database()

-- COMMAND ----------

desc EXTENDED demo.race_results_sql

-- COMMAND ----------

drop table demo.race_results_sql;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####External table or Unmanaged tables

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### 1) Create external table by using py
-- MAGIC ##### 2) Create external table by using SQl
-- MAGIC ##### 3) Effect droping of external table

-- COMMAND ----------

-- MAGIC %py
-- MAGIC race_results_df.write.mode("overWrite").format("parquet").option("path", f"{presentation_folder_path}/race_results_ext_py").saveAsTable("demo.race_results_ext_py")

-- COMMAND ----------

desc EXTENDED demo.race_results_ext_py;

-- COMMAND ----------

drop table demo.race_results_ext_sql ;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS demo.race_results_ext_sql 
(
race_year int,
race_name string,
race_date timestamp,
circuit_location string,
driver_name string,
driver_nationality string,
team string,
grid int,
fastest_lap int,
race_time string,
points float,
position int,
created_date timestamp
)using parquet
LOCATION '/mnt/formuladl62/presentation/race_results_ext_sql'


-- COMMAND ----------

-- MAGIC %python
-- MAGIC table_df = spark.table("demo.race_results_ext_sql")
-- MAGIC columns = len(table_df.columns)
-- MAGIC print("Number of columns in the table: ", columns)

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

INSERT INTO demo.race_results_ext_sql
select *from  demo.race_results_ext_py where (race_year=2020);


-- COMMAND ----------

select count(1) from demo.race_results_ext_sql;

-- COMMAND ----------

select *from demo.race_results_ext_sql;

-- COMMAND ----------

show tables in demo;

-- COMMAND ----------

drop table demo.race_results_ext_sql;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #external table after droping also explorer it will available so we need use extra command
-- MAGIC #Managed Table-spark will manges and maintain both meta data and data and but in external table  spark only maintain meta data and data will maintain by the user 

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #tempview only spark session not outside of notebook and out of the spark session
-- MAGIC #Globaltemp View its available within spark application to anybook which is attached for particular cluster

-- COMMAND ----------



-- COMMAND ----------

create OR Replace Temp View v_race_results as
select *from demo.race_results_python where race_year=2018;

-- COMMAND ----------

select *from v_race_results;

-- COMMAND ----------

create OR Replace GLOBAL temp View gv_race_results as
select *from demo.race_results_python where race_year=2012;

-- COMMAND ----------

select * from gv_race_results;

-- COMMAND ----------

select * from global_temp.gv_race_results;

-- COMMAND ----------

show tables in global_temp;

-- COMMAND ----------

-- MAGIC %python
-- MAGIC #perment view which is registeted in hive metastore and its prement and irresptive of cluster 

-- COMMAND ----------

create OR Replace View pv_race_results as
select *from demo.race_results_python where race_year=2000;

-- COMMAND ----------

select *from pv_race_results;

-- COMMAND ----------

show tables in demo;


-- COMMAND ----------

-- MAGIC %python
-- MAGIC current_db = spark.catalog.currentDatabase()
-- MAGIC print(current_db)

-- COMMAND ----------

