-- Databricks notebook source
use f1_processed;

-- COMMAND ----------

show tables;

-- COMMAND ----------

SELECT current_database();


-- COMMAND ----------

show tables;

-- COMMAND ----------

select current_database();

-- COMMAND ----------

use f1_processed;

-- COMMAND ----------

show tables;

-- COMMAND ----------

select count(race_year) from race_sql_results;

-- COMMAND ----------

select count(race_id) from lap_times where (position =13 and lap =26) or  race_id=67 limit 2456;

-- COMMAND ----------

select *from lap_times where( position =13 and lap=26)or race_id =67 order by race_id desc;

-- COMMAND ----------

select *from pitstop;

-- COMMAND ----------

select * from drivers;

-- COMMAND ----------

select *,CONCAT(driver_ref,'-',code )as new_driver_ref from drivers;

-- COMMAND ----------

select *,split(name,' ')from drivers;

-- COMMAND ----------

select *,split(name,' ')[0]forename,split (name,' ' ) [1] surname from drivers;

-- COMMAND ----------

select *,current_timestamp from drivers;

-- COMMAND ----------

select *,date_format(dob,'dd-MM-yyyy')from drivers;

-- COMMAND ----------

select *,date_add(dob,-2)from drivers;

-- COMMAND ----------

select max(dob) from drivers;

-- COMMAND ----------

select * from drivers where dob='
2000-05-11';

-- COMMAND ----------

select 
nationality
,count(*) as count from drivers group by 
nationality
order by 
nationality asc;

-- COMMAND ----------

select 
nationality,count(*) as count from drivers group by 
nationality having count>100
order by 
nationality asc

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####Window functions

-- COMMAND ----------

--drivers in each nationality group, ordered by their age rank within that group, so you can easily see who the oldest and youngest drivers are in each group.
select nationality,name,dob,RANK() over(PARTITION by nationality order by dob desc) as age_rank from drivers order by nationality,age_rank;

-- COMMAND ----------

