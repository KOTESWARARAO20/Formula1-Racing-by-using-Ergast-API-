-- Databricks notebook source
use f1_presentation;

-- COMMAND ----------

DESC driver_standings_sql;

-- COMMAND ----------

REFRESH TABLE driver_standings_sql;

-- COMMAND ----------

select * from driver_standings_sql;

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_driver_standings_2018
as  
select race_year,driver_name,team,total_points,wins,rank
from  driver_standings_sql where race_year=2018;

-- COMMAND ----------

select * from v_driver_standings_2018;

-- COMMAND ----------

CREATE OR REPLACE TEMP VIEW v_driver_standings_2020
as  
select race_year,driver_name,team,total_points,wins,rank
from  driver_standings_sql where race_year=2020;

-- COMMAND ----------

select * from v_driver_standings_2020;

-- COMMAND ----------

