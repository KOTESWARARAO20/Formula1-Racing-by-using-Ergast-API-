# Databricks notebook source
# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %md
# MAGIC #### Aggregation_Demo

# COMMAND ----------

# MAGIC %md
# MAGIC ####Built-in Aggregate Functions

# COMMAND ----------

race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_dummy_results_parquet")

# COMMAND ----------

display(race_results_df)


# COMMAND ----------

from pyspark.sql.functions import count,countDistinct,sum

# COMMAND ----------

demo_df=race_results_df

# COMMAND ----------

demo_df.select(count("*")).show()

# COMMAND ----------

demo_df.select(count("race_name")).show()

# COMMAND ----------

demo_df.select(countDistinct("race_name")).show()

# COMMAND ----------

demo_df.select(sum("points")).show()

# COMMAND ----------

demo_df.filter("driver_name='Valtteri Bottas' ").select(sum("points")).show()

# COMMAND ----------

demo_df.filter("driver_name='Valtteri Bottas' ").select(sum("points"),countDistinct("race_name"))\
.withColumnRenamed("sum(points)","total_points")\
.withColumnRenamed("count(Distinct race_name)","number_of_races").show()

# COMMAND ----------

# MAGIC %md
# MAGIC ####groupby

# COMMAND ----------

demo_df\
.groupBy("driver_name")\
.agg(sum("points"),countDistinct("race_name"))\
.show()

# COMMAND ----------

#we can use either cloumn renamed or else simple allis

# COMMAND ----------

demo_df\
.groupby("driver_name")\
.agg(sum("points").alias("total_points"),countDistinct("race_name").alias("number_of_races"))\
.show()

# COMMAND ----------

#group by is summarized data that what ever we applied on data and also we can apply any no.of agg functions by using pyspark.sql.GroupedData.agg

# COMMAND ----------

# MAGIC %md
# MAGIC ### windows functions

# COMMAND ----------

demo_df1=spark.read.parquet(f"{presentation_folder_path}/race_dummy1_results_parquet")

# COMMAND ----------

display(demo_df1)

# COMMAND ----------

demo_grouped_df=demo_df1\
.groupby("race_year","driver_name")\
.agg(sum("points").alias("total_points"),countDistinct("race_name").alias("number_of_races"))

# COMMAND ----------

display(demo_grouped_df)

# COMMAND ----------

#give the rank basrd on points and applied functions and partition the race_year

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import desc,rank,row_number,dense_rank,percent_rank

# COMMAND ----------

#rank Function

# COMMAND ----------

driveRankSpec=Window.partitionBy("race_year").orderBy(desc("total_points"))
demo_grouped_df.withColumn("rank",rank().over(driveRankSpec)).show(100)

# COMMAND ----------

#row_number
driveRankSpec=Window.partitionBy("race_year").orderBy(desc("total_points"))
demo_grouped_df.withColumn("row_number",row_number().over(driveRankSpec)).show(100)

# COMMAND ----------

#dense_rank Window Function
driveRankSpec=Window.partitionBy("race_year").orderBy(desc("total_points"))
demo_grouped_df.withColumn("dense_rank",dense_rank().over(driveRankSpec)).show(100)

# COMMAND ----------

#percent_rank Window Function
driveRankSpec=Window.partitionBy("race_year").orderBy(desc("total_points"))
demo_grouped_df.withColumn("percent_rank",percent_rank().over(driveRankSpec)).show(100)

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from global_temp.gv_race_results

# COMMAND ----------

