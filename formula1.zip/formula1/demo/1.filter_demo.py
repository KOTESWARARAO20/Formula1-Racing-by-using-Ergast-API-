# Databricks notebook source
# MAGIC %run "../includes/configurations"

# COMMAND ----------

races_df=spark.read.parquet(f"{processed_folder_path}/races_parquet")

# COMMAND ----------

##SQL way
races_filtered_df=display(races_df.filter("race_year=2019").collect())

# COMMAND ----------

#python way
races_filtered_df1=races_df.filter(races_df['race_year']==2019).collect()

# COMMAND ----------

#sql way
races_filtered_df1=races_df.filter("race_year=2019 and round<=5").collect()


# COMMAND ----------

races_filtered_df1=display(races_df.filter((races_df['race_year']==2019 )&(races_df['round']<=5)).collect())

# COMMAND ----------

#using where clause its same acts like filter
races_filtered_df1=display(races_df.where((races_df['race_year']==2019 )&(races_df['round']<=5)).collect())

# COMMAND ----------

