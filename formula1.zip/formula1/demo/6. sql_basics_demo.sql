-- Databricks notebook source
show databases;

-- COMMAND ----------

use f1_processed;


-- COMMAND ----------

show tables ;

-- COMMAND ----------

select *from f1_processed.drivers limit 100;

-- COMMAND ----------

desc drivers;

-- COMMAND ----------

select *from f1_processed.drivers where nationality="British";

-- COMMAND ----------

select *from f1_processed.drivers where nationality="British" and dob>='1990-01-01';

-- COMMAND ----------

select name,dob as date_of_birth from f1_processed.drivers where nationality="British" order by date_of_birth;

-- COMMAND ----------

select * from f1_processed.drivers  order by nationality asc, dob DESC;

-- COMMAND ----------

select name ,nationality,dob from f1_processed.drivers where (nationality="British" and dob>='1990-01-01') or nationality="Indian" order by dob desc;

-- COMMAND ----------

