# Databricks notebook source
# MAGIC %run "../includes/configurations"

# COMMAND ----------

circuits_df=spark.read.parquet(f"{processed_folder_path}/circuits_parquet").withColumnRenamed("name","circuit_name").filter("circuit_id<70")

# COMMAND ----------

races_df=spark.read.parquet(f"{processed_folder_path}/races_parquet").filter("race_year==2019").withColumnRenamed("name","race_name")

# COMMAND ----------

display(races_df)

# COMMAND ----------

display(circuits_df)

# COMMAND ----------

#join condition
circuits_races_df=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"inner")

# COMMAND ----------

#here circuit id cloumns repeat twice and name also repeat twice one is racer name another is circuit name in the circuit for that purpose we are using select command 
display(circuits_races_df)

# COMMAND ----------

circuits_races_df1=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"inner").select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Outer_Joins 
# MAGIC ########Left outer join

# COMMAND ----------

circuits_races_leftouter_df=circuits_races_df1=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"left").select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)

# COMMAND ----------

display(circuits_races_leftouter_df)


# COMMAND ----------

circuits_races_righttouter_df=circuits_races_df1=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"right").select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)

# COMMAND ----------

display(circuits_races_righttouter_df)

# COMMAND ----------

circuits_races_fullouter_df=circuits_races_df1=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"full").select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)

# COMMAND ----------

display(circuits_races_fullouter_df)

# COMMAND ----------

# MAGIC %md
# MAGIC #####Semi Joins can use semi or semi left
# MAGIC #####simarly to inner join   statsifying based on condition which will provide leftside table,Semi” means that we don’t really join the right hand side, we only check if a join would yield results for any given tuple.u have acess left df and do not have acess to the right dataframe fileds.

# COMMAND ----------

#circuits_races_semi_df=circuits_races_df1=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"semi").select(circuits_df.circuit_name,circuits_df.location,circuits_df.country,races_df.race_name,races_df.round)
#circuits_races_semi_df=circuits_races_df1=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"semi").select(circuits_df.circuit_name,circuits_df.location,circuits_df.country)
circuits_races_semi_df=circuits_races_df1=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"semi")

# COMMAND ----------

display(circuits_races_semi_df)

# COMMAND ----------

# MAGIC %md
# MAGIC ####Anti Joins and oppsite to semi join

# COMMAND ----------

circuits_races_anti_df=circuits_df.join(races_df,circuits_df.circuit_id== races_df.circuit_id,"anti")

# COMMAND ----------

display(circuits_races_anti_df)

# COMMAND ----------

circuits_races_anti_df1=races_df.join(circuits_df,circuits_df.circuit_id== races_df.circuit_id,"anti")

# COMMAND ----------

display(circuits_races_anti_df1)

# COMMAND ----------

# MAGIC %md 
# MAGIC ####Cross joins

# COMMAND ----------

circuits_races_cross_df=races_df.crossJoin(circuits_df)

# COMMAND ----------

display(circuits_races_cross_df)


# COMMAND ----------

circuits_races_cross_df.count()


# COMMAND ----------

int(circuits_df.count())*int(races_df.count())


# COMMAND ----------

#https://www.bbc.com/sport/formula1/2020/results

# COMMAND ----------

