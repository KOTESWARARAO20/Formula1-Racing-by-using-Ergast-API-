-- Databricks notebook source
CREATE DATABASE f1_raw;

-- COMMAND ----------

show tables in f1_raw;

-- COMMAND ----------

drop table if  exists f1_raw.circuits;

-- COMMAND ----------

CREATE TABLE IF NOT EXISTS f1_raw.circuits(
circuitId int,
circuitRef STRING,
name string,
location string,
country string,
lat double,
lng double,
alt int,
url string)
USING csv
OPTIONS(path "/mnt/formula1dl62/raw/circuits.csv",header true)

-- COMMAND ----------

select * from f1_raw.circuits;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####createing raw table for races csv 

-- COMMAND ----------

drop table if EXISTS f1_raw.races;

-- COMMAND ----------

create table if not exists f1_raw.races(
raceId string,
year string,
round  string ,
circuitId string,
name string,
date string,
time string,
url string)
using csv
options(path "/mnt/formula1dl62/raw/races.csv",
header true)

-- COMMAND ----------

select * from f1_raw.races;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####creating raw table 
-- MAGIC ####create consutrctors table 
-- MAGIC #####. single line JSON
-- MAGIC #####.Simple Strcture

-- COMMAND ----------

drop table if exists f1_raw.constructors;
CREATE TABLE IF NOT EXISTS f1_raw.constructors(
constructorId INT,
constructorRef STRING,
name STRING,
nationality STRING,
url STRING)
using json OPTIONS(path "/mnt/formula1dl62/raw/constructors.json")

-- COMMAND ----------

select * from f1_raw.constructors;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #####creating drivers json table,complex strcture  and single line json file

-- COMMAND ----------

drop table if exists f1_raw.drivers;
create table if not exists f1_raw.drivers(
driverId int,
driverRef STRING,
number int,
code string,
name STRUCT<forename :STRING,surname:STRING>,
dob DATE,
nationality STRING,
url STRING
)
using json
OPTIONS(path "/mnt/formula1dl62/raw/drivers.json")

-- COMMAND ----------

select * from f1_raw.drivers;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ###Results json file and single json file and simple strcture

-- COMMAND ----------

drop table if exists f1_raw.results;
create table if not exists f1_raw.results
(
resultId int,
raceId int,
driverId int,
constructorId int,
number int,
grid int,
position int,
positionText string,
positionOrder int,
points int,
laps int,
time string,
milliseconds int,
fastestLap int,
rank int,
fastestLapTime string,
fastestLapSpeed float,
statusId int
)
using json
OPTIONS(path "/mnt/formula1dl62/raw/results.json")

-- COMMAND ----------

select * from f1_raw.results;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ### creating pit stop table and multiline strcture

-- COMMAND ----------

drop table if exists f1_raw.pit_stops;
create table if not exists f1_raw.pit_stops(
driverId int,
duration string,
lap int,
milliseconds int,
raceId int,
stop int,
time string
)
using json
options(path "/mnt/formula1dl62/raw/pit_stops.json",multiLine true)

-- COMMAND ----------

select * from f1_raw.pit_stops;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ####Create lap times Table
-- MAGIC ##### .Json file
-- MAGIC ##### .Multiple Line Json
-- MAGIC ##### .Multiple Lines

-- COMMAND ----------

drop table if exists f1_raw.lap_times;
create table if not exists f1_raw.lap_times(
raceId int,
driverId int,
lap int,
position int,
time string,
milliseconds int)
using csv
OPTIONS( path "/mnt/formula1dl62/raw/lap_times")

-- COMMAND ----------

select *from f1_raw.lap_times;

-- COMMAND ----------

-- MAGIC %md
-- MAGIC ##### Create Qualifying table
-- MAGIC ##### .Json file
-- MAGIC ##### .Multiple Json
-- MAGIC ##### .Multiple files

-- COMMAND ----------

drop table if  exists f1_raw.qualifyig;
create table if not exists f1_raw.qualifyig(
constructorId int,
driverId int,
qualifyId int,
raceId int,
number int,
position int,
q1 string,
q2 string,
q3 string
)
using json
OPTIONS(path "/mnt/formula1dl62/raw/qualifying",multiLine true)

-- COMMAND ----------

select * from f1_raw.qualifyig;

-- COMMAND ----------

desc EXTENDED f1_raw.qualifyig;

-- COMMAND ----------

